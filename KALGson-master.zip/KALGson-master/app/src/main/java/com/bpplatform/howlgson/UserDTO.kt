package com.bpplatform.howlgson

/**
 * Created by myeongsic on 2018. 3. 12..
 */

class UserDTO {
    var name: String? = null
    var age: Int = 0
    var city: String? = null
}
